import Vue from 'vue';
import backgrounds from '../data/backgrounds'

export const Store = new Vue({
 data() {
     return {
        backgrounds
     };
 }
});