<template>
    <div class="nav">
        <el-menu
        :default-active="activeIndex2"
        class="el-menu-demo"
        mode="horizontal"
        @select="handleSelect"
        background-color="#545c64"
        text-color="#fff"
        active-text-color="#ffd04b">
        <el-menu-item index="1">
            <nuxt-link to="/">Home</nuxt-link>
        </el-menu-item>
        <el-menu-item index="2">
            <template slot="title">Encounters</template>
        </el-menu-item>
        <el-menu-item index="3" disabled>
            <nuxt-link to="/backgrounds">Backgrounds</nuxt-link>
        </el-menu-item>
        <el-menu-item index="4"><a href="https://www.ele.me" target="_blank">Last thing</a></el-menu-item>
        </el-menu>
    </div>
</template>
<script>
  export default {
    data() {
      return {
        activeIndex: '1',
        activeIndex2: '1'
      };
    },
    methods: {
      handleSelect(key, keyPath) {
        console.log(key, keyPath);
      }
    }
  }
</script>