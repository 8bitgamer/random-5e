<template>
  <section class="backgrounds">
    <el-row type="flex" justify="center">
      <el-col :span="15">
        <ul>
          <li v-for="(background, index) in backgrounds.background" :key="background.name">
            <el-row class="background__wrapper">
              <el-col :span="8">
                <span class="background__name">{{ background.name }}</span>
                <p class="background__source">{{ background.source }} </p>
                {{ index }}
              </el-col>
              <el-col :span="8" class="list-row-primary-text">
                {{ background.proficiency }}
              </el-col>
            </el-row>      
          </li>
        </ul>
      </el-col>
    </el-row>
  </section>
</template>

<script>
import { Store } from '~/store/Store'

export default {
  data() {
    return {
      backgrounds: Store.$data.backgrounds
    }   
  }
}
</script>

<style>
.background__name {
  text-overflow: ellipsis;
  white-space: nowrap;
  overflow: hidden;
  color: #242527;
  font-size: 18px;
  font-weight: 500;
}

.background__source {
  text-overflow: ellipsis;
  white-space: nowrap;
  overflow: hidden;
  color: #979AA4;
  font-size: 12px;
  font-weight: 500;
}

.background__wrapper {
  background: url('~/assets/images/1a.png');
  background-repeat: no-repeat;
  padding: 17px;
  background-size: 100% 100%;
  transition: background-image .2s cubic-bezier(0.17,0.67,0.83,0.67);
  cursor: pointer;
}

.background__wrapper:hover {
  background: url('~/assets/images/1a-hover.png');
  background-repeat: no-repeat;
  background-size: 100% 100%;
  transition: background-image .2s cubic-bezier(0.17,0.67,0.83,0.67);
}

li {
  list-style: none;
}

.list-row-primary-text {
    text-overflow: ellipsis;
    white-space: nowrap;
    overflow: hidden;
    color: #242527;
    font-size: 14px;
    font-weight: 500;    
    line-height: 40px;
}
</style>

